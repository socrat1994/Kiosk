<?php

return $Route_middles = [
   'auth' => 'App\\Middleware\\Auth',
   'guest' => 'App\\Middleware\\Guest',
    'role' => 'App\\Middleware\\RoleMiddle',

];
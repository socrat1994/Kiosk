<?php

namespace App\Model;

use General\Database\Model;

class Archive extends Model
{
    public static $table_name = 'archive';
}
<?php

namespace App\Model;

use General\Database\Model;

class Role extends Model
{
    public $columns = 'roles';
}
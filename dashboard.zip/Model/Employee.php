<?php

namespace App\Model;

use General\Database\Model;

class Employee extends Model
{
}
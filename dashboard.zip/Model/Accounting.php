<?php

namespace App\Model;

use General\Database\Model;

class Accounting extends Model
{

    public function taker()
    {
        //return $this->foreign('');
    }

}
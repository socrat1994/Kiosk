<?php

namespace Controllers;

use App\Model\Accounting;
use App\Model\Archive;
use App\Model\Good;
use App\Model\Quantity;
use App\Model\StockTaker;
use App\Model\User;
use General\Request;
use General\Roles;
use General\Route;
use General\Session;
use App\Model\Employee;
use General\Validation\Validation;

class GoodsController
{
    public function __construct()
    {
        Roles::$roles = ['deliveryView' => 'admin', 'accounting' =>
            'admin', 'addToStoreView' => 'admin', 'deliver' => 'admin', 'addToStore' => 'admin'];
    }

    public function takeStockView()
    {
        return Route::data('goods/take_view');
    }

    public function deliveryView()
    {
        $data = Route::data('goods/take_view');
        $data['form']['submitto'] = Route('goods/deliver');
        $data['form']['head'] = __v('deliver');
        $data['inputs'][] = [
            'column' => 2,
            'label' => __v('kiosk'),
            'type' => "number",
            'name' => 'kiosk_id'
        ];
        return $data;
    }

    public function accounting()
    {
        $data = Route::data('goods/accounting_view');
        return $data;
    }

    public function addToStoreView()
    {
        $data = Route::data('goods/take_view');
        $data['form']['submitto'] = Route('goods/addtostore/add');
        $data['form']['head'] = __v('add to store');
        return $data;
    }

    public function takeStock(Request $request)
    {
        $request = $request->get();
        $val = new Validation($request);
        $validationResult = $this->validateRequest($request);
        if ($validationResult) {
            return $validationResult;
        }
        $sales = 0;
        $costs = 0;
        $goods = new Good(Good::class);
        $user = Session::get('user');
        $stockTakerId = StockTaker::insert([['user_id' => $user->id, 'date' => date('Y-m-d')]]);
        [$employee] = Employee::get('user_id=' . $user->id);
        $data = $goods
            ->columns('t1.quantity ,t0.selling ,t0.cost,t0.id')
            ->quantities()
            ->get_('t1.kiosk_id=' . $employee->kiosk_id);
        $dataMap = [];
        foreach ($data as $row) {
            $dataMap[$row->id] = $row;
        }
        foreach ($request as $goodId => $quantity) {
            $data = isset($dataMap[$goodId]) ? $dataMap[$goodId] : null;
            if ($quantity !== '') {
                $current_quantity = $quantity;
                $def = $data->quantity - $current_quantity;
                if ($def) {
                    $sales += ($def) * $data->selling;
                    $costs += ($def) * $data->cost;
                    $net_income = $sales - $costs;
                    $updateQty[] = ['where' => 'good_id=' . $goodId, 'values' => ['quantity' => $quantity]];
                }
            }
            $archive[] = ['taker_id' => $stockTakerId, 'good_id' => $goodId,
                'last_quantity' => $data->quantity,
                'current_quantity' => $current_quantity ?? $data->quantity,
                'opration' => '-1'
            ];
        }
        if ($sales) {
            $accountings[] = ['sales' => $sales, 'costs' => $costs, 'net_income' => $net_income, 'taker_id' => $stockTakerId];
            Accounting::insert($accountings);
            Archive::insert($archive);
            Quantity::update($updateQty);
        }
        return ['common' => ['i' => __v('done'), 'stop' => true]];
    }

    public function deliver(Request $request)
    {
        $request = $request->get();
        $validationResult = $this->validateRequest($request, ['kiosk_id' => ['required']]);
        if ($validationResult) {
            return $validationResult;
        }
        $goods = new Good(Good::class);
        $user = Session::get('user');
        $stockTakerId = StockTaker::insert([['user_id' => $user[0]->id, 'date' => date('Y-m-d')]]);
        $employee = Employee::get('user_id=' . $user[0]->id);
        $kioskData = $goods
            ->columns('t1.quantity,t0.id')
            ->quantities()
            ->get_('t1.kiosk_id=' . $request['kiosk_id']);
        $goods = new Good(Good::class);
        $storeData = $goods
            ->columns('t1.quantity ,t0.selling ,t0.cost,t0.id')
            ->quantities()
            ->get_('t1.kiosk_id=' . $employee[0]->kiosk_id);
        $dataMap = [];
        foreach ($kioskData as $row) {
            $dataMap[$row->id] = $row;
        }
        $kioskData = $dataMap;
        $dataMap = [];
        foreach ($storeData as $row) {
            $dataMap[$row->id] = $row;
        }
        $storeData = $dataMap;
        foreach ($request as $goodId => $quantity) {
            if ($goodId === 'kiosk_id') {
                break;
            }
            $storeQuantity = $storeData[$goodId]->quantity;
            if ($quantity) {
                $kioskQuantity = $kioskData[$goodId]->quantity;
                $deliverQuantity = $quantity;
                $kioskQuantityAf = $kioskQuantity + $deliverQuantity;
                $storeQuantityAf = $storeQuantity - $deliverQuantity;
                $where = 'good_id=' . $goodId . ' AND kiosk_id=';
                $updateStore[] = ['where' => $where . $employee[0]->kiosk_id, 'values' => ['quantity' => $storeQuantityAf]];
                $updateKiosk[] = ['where' => $where . $request['kiosk_id'], 'values' => ['quantity' => $kioskQuantityAf]];
            }
            $storeArchive[] = ['taker_id' => $stockTakerId, 'good_id' => $goodId,
                'last_quantity' => $storeQuantity,
                'current_quantity' => $storeQuantityAf ?? $storeQuantity,
                'opration' => $request['kiosk_id']
            ];
        }
        Archive::insert($storeArchive);
        Quantity::update($updateStore);
        Quantity::update($updateKiosk);
        return ['common' => ['i' => __v('done'), 'stop' => true]];
    }

    public function addToStore(Request $request)
    {
        $request = $request->get();
        $validationResult = $this->validateRequest($request);
        if ($validationResult) {
            return $validationResult;
        }
        $goods = new Good(Good::class);
        $user = Session::get('user');
        [$employee] = Employee::get('user_id=' . $user->id);
        $stockTakerId = StockTaker::insert([['user_id' => $user->id, 'date' => date('Y-m-d')]]);
        $storeData = $goods
            ->columns('t1.quantity,t0.id')
            ->quantities()
            ->get_('t1.kiosk_id=' . $employee->kiosk_id);
        $storeQuantities = [];
        foreach ($storeData as $row) {
            $storeQuantities[$row->id] = $row->quantity;
        }
        foreach ($request as $goodId => $quantityToAdd) {
            ($quantityToAdd === '') ? $quantityToAdd = 0 : '';
            $storeQuantityAf = $storeQuantities[$goodId] + $quantityToAdd;
            $where = 'good_id=' . $goodId . ' AND kiosk_id=';
            if ($quantityToAdd) {
                $updateStore[] = ['where' => $where . $employee->kiosk_id, 'values' =>
                    ['quantity' => $storeQuantityAf]];
            }
            $archive[] = ['taker_id' => $stockTakerId, 'good_id' => $goodId,
                'last_quantity' => $storeQuantities[$goodId],
                'current_quantity' => $storeQuantityAf,
                'opration' => 0
            ];
        }
        Archive::insert($archive);
        Quantity::update($updateStore);
        return ['common' =>['i' => __v('done'), 'stop' => true]];
    }

    function validateRequest($request, $additionalValidations = []) {
        $val = new Validation($request);
        $val->all(['Num,0']);
        if (!empty($additionalValidations)) {
            $val->addValidation($request, $additionalValidations);
        }
        if (!Validation::$valid) {
            $messages = Validation::$message;
            $messages['common'] = __v('look above for wrong insertion');
            return ['errors' => $messages];
        }
        return null;
    }
}

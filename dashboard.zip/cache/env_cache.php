<?php return array (
  'DOMAIN' => 'http://192.168.1.5/dashboard/',//'https://7a0b-185-172-73-178.ngrok-free.app/dashboard/',
  'HOST' => 'localhost',
  'USERNAME' => 'root',
  'PASSWORD' => '',
  'DBNAME' => 'scandiweb_test',
  'LANG' => 'en',
);
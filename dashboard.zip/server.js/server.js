console.log("hello world");
var a = "matza";
var number = 26;
var isMale = true;


var  myFunc = function(){
	
	console.log("my name is "+a+" i am "+number+" ");
	
	
	
	
}

myFunc();
<?php

return [
    'logerm' => 'Invalid phone or password. Please try again.',
];
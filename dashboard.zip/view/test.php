
<div class="container">
    <div class="header">
        <div class="header-col">sign in</div>
    </div>
    <div class="row" lang="en">
        <div class="col col-1" >name</div>
        <div class="col col-2"><input type="text"></div>
    </div>
    <div class="row" lang="en">
        <div class="col col-1" >phone</div>
        <div class="col col-2"><input type="text"></div>
    </div>
    <div class="row" lang="en">
        <div class="col col-1" >pass</div>
        <div class="col col-2"><input type="text"></div>
    </div>
    <div class="row">
        <div class="col"><button>submit</button></div>
    </div>
</div>

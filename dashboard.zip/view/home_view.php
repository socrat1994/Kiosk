

<div class="col tex-c" ><div><h1>Welcome to AutoCare</h1>This application is designed to manage car
                maintenance operations within companies.
                I developed it using native PHP, without any packages or
                frameworks, to showcase my abilities. I also used my own CSS and
                JavaScript libraries. You can view the code in my repository and
                compare it with my previous project to see how I have developed my
                skills in a period of less than three months,
                despite having limited time </div></div>

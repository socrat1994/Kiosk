<?php
function __v($toTranslate)
{
    return \General\Language::t($toTranslate, 'view');
}
function __e($toTranslate)
{
    return \General\Language::t($toTranslate, 'error');
}
function __($file)
{
    return \General\Language::dictionary($file);
}
function __lang()
{
    return \General\Language::get();
}
function Route($url)
{
    return \General\Route::url($url);
}
function html()
{
    $lang = __lang();
    $dir = ($lang === 'ar') ? 'rtl' : 'ltr';
    echo 'lang="' . $lang . '" dir="' . $dir . '"';
}
function react($url)
{
    return '/dashboard/' . $url . '/';
}
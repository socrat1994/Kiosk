<?php

use App\Model\Good;

$dictionary = __('view');
$data = [
    'form' => [
        'submit' => $dictionary['submit'],
        'head' => $dictionary['Take Stock'],
        'submitto' => Route('goods/take/update'),
    ]
];
$goods = Good::get();
foreach ($goods as $good) {
   $data['inputs'][] = [
        'column' => 2,
        'label' => $good->name,
        'type' => "number",
        'name' => $good->id
    ];
}
return $data;